# HighMDT
a web MDT for QBCore Fivem servers to boost Police Roleplay
Licensekey (Free) is required https://pepe-framework.com/dbtech-ecommerce/meos-system-mdt.3/
