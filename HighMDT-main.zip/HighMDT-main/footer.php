
				</div>

			</div>
		</div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<!-- <script src="js/jquery.min.js"></script> -->
		<script src="js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
		<script src="js/nav.min.js"></script>
		<script src="js/moment.js"></script>
		<!-- Daterange -->
		<script src="vendor/daterange/daterange.js"></script>
		<!-- Apex Charts -->
		<script src="vendor/apex/apexcharts.min.js"></script>
		<script src="vendor/apex/custom/apexLineChartGradient.js"></script>
		<script src="vendor/apex/custom/apexColumnBasic.js"></script>
		<script src="vendor/apex/custom/apexAllCustomGraphs.js"></script>
		<!-- Main Js Required -->
		<script src="js/main.js"></script>
        <script src="assets/js/main.js"></script>

        <script src="assets/js/popper.min.js"></script>
	</body>
</html>